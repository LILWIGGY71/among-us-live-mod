export default {
	UNSUPPORTED_VERSION:
		'Your version of Among Us is unsupported by CrewLink.\n' +
		'CrewLink only supports the latest, non-beta STEAM version.',
	OPEN_AS_ADMINISTRATOR: "Couldn't connect to Among Us.\n" + 'Please re-open CrewLink as Administrator.',
};
