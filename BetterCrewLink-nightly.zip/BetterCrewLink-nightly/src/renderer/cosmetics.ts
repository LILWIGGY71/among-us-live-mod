// @ts-ignore
import hat1 from '../../static/hats/1.png'; // @ts-ignore
import hat2 from '../../static/hats/2.png'; // @ts-ignore
import hat3 from '../../static/hats/3.png'; // @ts-ignore
import hat4 from '../../static/hats/4.png'; // @ts-ignore
import hat5 from '../../static/hats/5.png'; // @ts-ignore
import hat6 from '../../static/hats/6.png'; // @ts-ignore
import hat7 from '../../static/hats/7.png'; // @ts-ignore
import hat8 from '../../static/hats/8.png'; // @ts-ignore
import hat9 from '../../static/hats/9.png'; // @ts-ignore
import hat10 from '../../static/hats/10.png'; // @ts-ignore
import hat11 from '../../static/hats/11.png'; // @ts-ignore
import hat12 from '../../static/hats/12.png'; // @ts-ignore
import hat13 from '../../static/hats/13.png'; // @ts-ignore
import hat14 from '../../static/hats/14.png'; // @ts-ignore
import hat15 from '../../static/hats/15.png'; // @ts-ignore
import hat16 from '../../static/hats/16.png'; // @ts-ignore
import hat17 from '../../static/hats/17.png'; // @ts-ignore
import hat18 from '../../static/hats/18.png'; // @ts-ignore
import hat19 from '../../static/hats/19.png'; // @ts-ignore
import hat20 from '../../static/hats/20.png'; // @ts-ignore
import hat21 from '../../static/hats/21.png'; // @ts-ignore
import hat22 from '../../static/hats/22.png'; // @ts-ignore
import hat23 from '../../static/hats/23.png'; // @ts-ignore
import hat24 from '../../static/hats/24.png'; // @ts-ignore
import hat25 from '../../static/hats/25.png'; // @ts-ignore
import hat26 from '../../static/hats/26.png'; // @ts-ignore
import hat27 from '../../static/hats/27.png'; // @ts-ignore
import hat28 from '../../static/hats/28.png'; // @ts-ignore
import hat29 from '../../static/hats/29.png'; // @ts-ignore
import hat30 from '../../static/hats/30.png'; // @ts-ignore
import hat31 from '../../static/hats/31.png'; // @ts-ignore
import hat32 from '../../static/hats/32.png'; // @ts-ignore
import hat33 from '../../static/hats/33.png'; // @ts-ignore
import hat34 from '../../static/hats/34.png'; // @ts-ignore
import hat35 from '../../static/hats/35.png'; // @ts-ignore
import hat36 from '../../static/hats/36.png'; // @ts-ignore
import hat37 from '../../static/hats/37.png'; // @ts-ignore
import hat38 from '../../static/hats/38.png'; // @ts-ignore
import hat39 from '../../static/hats/39.png'; // @ts-ignore
import hat40 from '../../static/hats/40.png'; // @ts-ignore
import hat41 from '../../static/hats/41.png'; // @ts-ignore
import hat42 from '../../static/hats/42.png'; // @ts-ignore
import hat43 from '../../static/hats/43.png'; // @ts-ignore
import hat44 from '../../static/hats/44.png'; // @ts-ignore
import hat45 from '../../static/hats/45.png'; // @ts-ignore
import hat46 from '../../static/hats/46.png'; // @ts-ignore
import hat47 from '../../static/hats/47.png'; // @ts-ignore
import hat48 from '../../static/hats/48.png'; // @ts-ignore
import hat49 from '../../static/hats/49.png'; // @ts-ignore
import hat50 from '../../static/hats/50.png'; // @ts-ignore
import hat51 from '../../static/hats/51.png'; // @ts-ignore
import hat52 from '../../static/hats/52.png'; // @ts-ignore
import hat53 from '../../static/hats/53.png'; // @ts-ignore
import hat54 from '../../static/hats/54.png'; // @ts-ignore
import hat55 from '../../static/hats/55.png'; // @ts-ignore
import hat56 from '../../static/hats/56.png'; // @ts-ignore
import hat57 from '../../static/hats/57.png'; // @ts-ignore
import hat58 from '../../static/hats/58.png'; // @ts-ignore
import hat59 from '../../static/hats/59.png'; // @ts-ignore
import hat60 from '../../static/hats/60.png'; // @ts-ignore
import hat61 from '../../static/hats/61.png'; // @ts-ignore
import hat62 from '../../static/hats/62.png'; // @ts-ignore
import hat63 from '../../static/hats/63.png'; // @ts-ignore
import hat64 from '../../static/hats/64.png'; // @ts-ignore
import hat65 from '../../static/hats/65.png'; // @ts-ignore
import hat66 from '../../static/hats/66.png'; // @ts-ignore
import hat67 from '../../static/hats/67.png'; // @ts-ignore
import hat68 from '../../static/hats/68.png'; // @ts-ignore
import hat69 from '../../static/hats/69.png'; // @ts-ignore
import hat70 from '../../static/hats/70.png'; // @ts-ignore
import hat71 from '../../static/hats/71.png'; // @ts-ignore
import hat72 from '../../static/hats/72.png'; // @ts-ignore
import hat73 from '../../static/hats/73.png'; // @ts-ignore
import hat74 from '../../static/hats/74.png'; // @ts-ignore
import hat75 from '../../static/hats/75.png'; // @ts-ignore
import hat76 from '../../static/hats/76.png'; // @ts-ignore
import hat77 from '../../static/hats/77.png'; // @ts-ignore
import hat77_0 from '../../static/hats/77-0.png'; // @ts-ignore
import hat77_1 from '../../static/hats/77-1.png'; // @ts-ignore
import hat77_2 from '../../static/hats/77-2.png'; // @ts-ignore
import hat77_3 from '../../static/hats/77-3.png'; // @ts-ignore
import hat77_4 from '../../static/hats/77-4.png'; // @ts-ignore
import hat77_5 from '../../static/hats/77-5.png'; // @ts-ignore
import hat77_6 from '../../static/hats/77-6.png'; // @ts-ignore
import hat77_7 from '../../static/hats/77-7.png'; // @ts-ignore
import hat77_8 from '../../static/hats/77-8.png'; // @ts-ignore
import hat77_9 from '../../static/hats/77-9.png'; // @ts-ignore
import hat77_10 from '../../static/hats/77-10.png'; // @ts-ignore
import hat77_11 from '../../static/hats/77-11.png'; // @ts-ignore

import hat78 from '../../static/hats/78.png'; // @ts-ignore
import hat79 from '../../static/hats/79.png'; // @ts-ignore
import hat80 from '../../static/hats/80.png'; // @ts-ignore
import hat81 from '../../static/hats/81.png'; // @ts-ignore
import hat82 from '../../static/hats/82.png'; // @ts-ignore
import hat83 from '../../static/hats/83.png'; // @ts-ignore
import hat84 from '../../static/hats/84.png'; // @ts-ignore
import hat85 from '../../static/hats/85.png'; // @ts-ignore
import hat86 from '../../static/hats/86.png'; // @ts-ignore
import hat87 from '../../static/hats/87.png'; // @ts-ignore
import hat88 from '../../static/hats/88.png'; // @ts-ignore
import hat89 from '../../static/hats/89.png'; // @ts-ignore
import hat90 from '../../static/hats/90.png'; // @ts-ignore
import hat90_0 from '../../static/hats/90-0.png'; // @ts-ignore
import hat90_1 from '../../static/hats/90-1.png'; // @ts-ignore
import hat90_2 from '../../static/hats/90-2.png'; // @ts-ignore
import hat90_3 from '../../static/hats/90-3.png'; // @ts-ignore
import hat90_4 from '../../static/hats/90-4.png'; // @ts-ignore
import hat90_5 from '../../static/hats/90-5.png'; // @ts-ignore
import hat90_6 from '../../static/hats/90-6.png'; // @ts-ignore
import hat90_7 from '../../static/hats/90-7.png'; // @ts-ignore
import hat90_8 from '../../static/hats/90-8.png'; // @ts-ignore
import hat90_9 from '../../static/hats/90-9.png'; // @ts-ignore
import hat90_10 from '../../static/hats/90-10.png'; // @ts-ignore
import hat90_11 from '../../static/hats/90-11.png'; // @ts-ignore
import hat91 from '../../static/hats/91.png'; // @ts-ignore
import hat92 from '../../static/hats/92.png'; // @ts-ignore
import hat93 from '../../static/hats/93.png'; // @ts-ignore
import hat94 from '../../static/hats/94.png';

// @ts-ignore
import skin1 from '../../static/skins/1.png'; // @ts-ignore
import skin2 from '../../static/skins/2.png'; // @ts-ignore
import skin3 from '../../static/skins/3.png'; // @ts-ignore
import skin4 from '../../static/skins/4.png'; // @ts-ignore
import skin5 from '../../static/skins/5.png'; // @ts-ignore
import skin6 from '../../static/skins/6.png'; // @ts-ignore
import skin7 from '../../static/skins/7.png'; // @ts-ignore
import skin8 from '../../static/skins/8.png'; // @ts-ignore
import skin9 from '../../static/skins/9.png'; // @ts-ignore
import skin10 from '../../static/skins/10.png'; // @ts-ignore
import skin11 from '../../static/skins/11.png'; // @ts-ignore
import skin12 from '../../static/skins/12.png'; // @ts-ignore
import skin13 from '../../static/skins/13.png'; // @ts-ignore
import skin14 from '../../static/skins/14.png'; // @ts-ignore
import skin15 from '../../static/skins/15.png';

// @ts-ignore
import redAlive from '../../static/players/red-alive.png'; // @ts-ignore
import blueAlive from '../../static/players/blue-alive.png'; // @ts-ignore
import greenAlive from '../../static/players/green-alive.png'; // @ts-ignore
import pinkAlive from '../../static/players/pink-alive.png'; // @ts-ignore
import orangeAlive from '../../static/players/orange-alive.png'; // @ts-ignore
import yellowAlive from '../../static/players/yellow-alive.png'; // @ts-ignore
import blackAlive from '../../static/players/black-alive.png'; // @ts-ignore
import whiteAlive from '../../static/players/white-alive.png'; // @ts-ignore
import purpleAlive from '../../static/players/purple-alive.png'; // @ts-ignore
import brownAlive from '../../static/players/brown-alive.png'; // @ts-ignore
import cyanAlive from '../../static/players/cyan-alive.png'; // @ts-ignore
import limeAlive from '../../static/players/lime-alive.png';

// @ts-ignore
import redDead from '../../static/players/red-dead.png'; // @ts-ignore
import blueDead from '../../static/players/blue-dead.png'; // @ts-ignore
import greenDead from '../../static/players/green-dead.png'; // @ts-ignore
import pinkDead from '../../static/players/pink-dead.png'; // @ts-ignore
import orangeDead from '../../static/players/orange-dead.png'; // @ts-ignore
import yellowDead from '../../static/players/yellow-dead.png'; // @ts-ignore
import blackDead from '../../static/players/black-dead.png'; // @ts-ignore
import whiteDead from '../../static/players/white-dead.png'; // @ts-ignore
import purpleDead from '../../static/players/purple-dead.png'; // @ts-ignore
import brownDead from '../../static/players/brown-dead.png'; // @ts-ignore
import cyanDead from '../../static/players/cyan-dead.png'; // @ts-ignore
import limeDead from '../../static/players/lime-dead.png';

export interface PlayerImageColors {
	alive: string[];
	dead: string[];
}

export const players: PlayerImageColors = {
	alive: [
		redAlive,
		blueAlive,
		greenAlive,
		pinkAlive,
		orangeAlive,
		yellowAlive,
		blackAlive,
		whiteAlive,
		purpleAlive,
		brownAlive,
		cyanAlive,
		limeAlive,
	],
	dead: [
		redDead,
		blueDead,
		greenDead,
		pinkDead,
		orangeDead,
		yellowDead,
		blackDead,
		whiteDead,
		purpleDead,
		brownDead,
		cyanDead,
		limeDead,
	],
};

export const skins = [
	skin1,
	skin2,
	skin3,
	skin4,
	skin5,
	skin6,
	skin7,
	skin8,
	skin9,
	skin10,
	skin11,
	skin12,
	skin13,
	skin14,
	skin15,
];

export const hatOffsets: { [key in number]: string | undefined } = {
	7: '-50%',
	21: '-50%',
	28: '-50%',
	35: '-50%',
	77: '-50%',
	90: '-50%',
};

export const backLayerHats = new Set([39, 4, 6, 15, 29, 42, 75, 85]);

export const coloredHats: { [key in string]: string | undefined } = {
	77_0: hat77_0,
	77_1: hat77_1,
	77_2: hat77_2,
	77_3: hat77_3,
	77_4: hat77_4,
	77_5: hat77_5,
	77_6: hat77_6,
	77_7: hat77_7,
	77_8: hat77_8,
	77_9: hat77_9,
	77_10: hat77_10,
	77_11: hat77_11,

	90_0: hat90_0,
	90_1: hat90_1,
	90_2: hat90_2,
	90_3: hat90_3,
	90_4: hat90_4,
	90_5: hat90_5,
	90_6: hat90_6,
	90_7: hat90_7,
	90_8: hat90_8,
	90_9: hat90_9,
	90_10: hat90_10,
	90_11: hat90_11,
};

export const hats = [
	undefined,
	hat1,
	hat2,
	hat3,
	hat4,
	hat5,
	hat6,
	hat7,
	hat8,
	hat9,
	hat10,
	hat11,
	hat12,
	hat13,
	hat14,
	hat15,
	hat16,
	hat17,
	hat18,
	hat19,
	hat20,
	hat21,
	hat22,
	hat23,
	hat24,
	hat25,
	hat26,
	hat27,
	hat28,
	hat29,
	hat30,
	hat31,
	hat32,
	hat33,
	hat34,
	hat35,
	hat36,
	hat37,
	hat38,
	hat39,
	hat40,
	hat41,
	hat42,
	hat43,
	hat44,
	hat45,
	hat46,
	hat47,
	hat48,
	hat49,
	hat50,
	hat51,
	hat52,
	hat53,
	hat54,
	hat55,
	hat56,
	hat57,
	hat58,
	hat59,
	hat60,
	hat61,
	hat62,
	hat63,
	hat64,
	hat65,
	hat66,
	hat67,
	hat68,
	hat69,
	hat70,
	hat71,
	hat72,
	hat73,
	hat74,
	hat75,
	hat76,
	hat77,
	hat78,
	hat79,
	hat80,
	hat81,
	hat82,
	hat83,
	hat84,
	hat85,
	hat86,
	hat87,
	hat88,
	hat89,
	hat90,
	hat91,
	hat92,
	hat93,
	hat94,
];
